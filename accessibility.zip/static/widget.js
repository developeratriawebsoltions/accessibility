/* widget.js - drop into static/widget.js */
(function () {
  // Prevent double-initialization
  if (window.__aw_a11y_loaded) return;
  window.__aw_a11y_loaded = true;

  // ---------- Helpers ----------
  function getBaseUrl() {
    // find the current script tag src
    var script = document.currentScript;
    if (!script) {
      var scripts = document.getElementsByTagName('script');
      script = scripts[scripts.length - 1];
    }
    var src = script && script.src ? script.src : '';
    return src.replace(/\/widget\.js(\?.*)?$/, '') || '';
  }
  var BASE = getBaseUrl();

  function loadCSS(href) {
    var l = document.createElement('link');
    l.rel = 'stylesheet';
    l.href = href;
    l.crossOrigin = 'anonymous';
    document.head.appendChild(l);
  }

  // Load the CSS (served at /style.css by the flask app)
  try { loadCSS(BASE + '/style.css'); } catch (e) { console.warn('A11Y widget: css load failed', e); }

  // Preferences persistence
  var STORAGE_KEY = 'aw_a11y_prefs_v1';
  var prefs = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');

  function savePrefs() { localStorage.setItem(STORAGE_KEY, JSON.stringify(prefs)); }

  // ---------- State helpers - applying classes to <html> ----------
  var htmlEl = document.documentElement;

  function toggleClass(className, enabled) {
    if (enabled) htmlEl.classList.add(className);
    else htmlEl.classList.remove(className);
  }

  function applyAllPrefs() {
    toggleClass('aw-a11y-high-contrast', !!prefs.highContrast);
    toggleClass('aw-a11y-desaturate', !!prefs.desaturate);
    toggleClass('aw-a11y-dyslexia', !!prefs.dyslexia);
    toggleClass('aw-a11y-focus-outline', !!prefs.focusOutline);
    if (prefs.fontScale) applyFontScale(prefs.fontScale);
    if (prefs.lineHeight) applyLineHeight(prefs.lineHeight);
  }

  // font scale - we'll adjust root font-size (works for rem-based sites)
  var originalRootFontSize = parseFloat(window.getComputedStyle(document.documentElement).fontSize) || 16;
  function applyFontScale(scale) {
    if (!scale) {
      document.documentElement.style.fontSize = '';
      delete prefs.fontScale;
    } else {
      document.documentElement.style.fontSize = (originalRootFontSize * scale) + 'px';
      prefs.fontScale = scale;
    }
    savePrefs();
  }

  function applyLineHeight(value) {
    if (!value) {
      document.body.style.lineHeight = '';
      delete prefs.lineHeight;
    } else {
      document.body.style.lineHeight = value;
      prefs.lineHeight = value;
    }
    savePrefs();
  }

  // ---------- Text-to-Speech (TTS) ----------
  var tts = {
    utter: null,
    isSpeaking: false,
    start: function (text) {
      if (!window.speechSynthesis) {
        alert('Text-to-speech not supported in this browser.');
        return;
      }
      this.stop();
      this.utter = new SpeechSynthesisUtterance(text);
      this.utter.rate = prefs.ttsRate || 1;
      this.utter.pitch = prefs.ttsPitch || 1;
      window.speechSynthesis.speak(this.utter);
      this.isSpeaking = true;
    },
    pause: function () { if (window.speechSynthesis && window.speechSynthesis.speaking) window.speechSynthesis.pause(); },
    resume: function () { if (window.speechSynthesis && window.speechSynthesis.paused) window.speechSynthesis.resume(); },
    stop: function () { if (window.speechSynthesis) { window.speechSynthesis.cancel(); } this.isSpeaking = false; this.utter = null; }
  };

  // ---------- Toolbar UI ----------
  var toolbar = document.createElement('div');
  toolbar.className = 'aw-a11y-toolbar';
  toolbar.setAttribute('role', 'toolbar');
  toolbar.setAttribute('aria-label', 'Accessibility toolbar');

  // small helper to create buttons
  function createButton(label, title, onClick) {
    var b = document.createElement('button');
    b.type = 'button';
    b.title = title || label;
    b.innerHTML = label;
    b.addEventListener('click', function (e) { e.preventDefault(); onClick(e); });
    return b;
  }

  // READ (selection or page)
  var btnRead = createButton('🔊', 'Read selected text / page', function () {
    var sel = (window.getSelection && window.getSelection().toString && window.getSelection().toString().trim()) || '';
    var text = sel || (document.querySelector('main') ? document.querySelector('main').innerText : document.body.innerText);
    if (text && text.trim().length) {
      tts.start(text);
    } else {
      alert('No text found to read.');
    }
  });
  toolbar.appendChild(btnRead);

  // Pause & Resume & Stop TTS
  var btnPause = createButton('⏸', 'Pause reading', function () { tts.pause(); });
  var btnResume = createButton('▶', 'Resume reading', function () { tts.resume(); });
  var btnStop = createButton('⏹', 'Stop reading', function () { tts.stop(); });
  toolbar.appendChild(btnPause);
  toolbar.appendChild(btnResume);
  toolbar.appendChild(btnStop);

  // High contrast toggle
  var btnContrast = createButton('🌓', 'Toggle high contrast', function () {
    prefs.highContrast = !prefs.highContrast;
    toggleClass('aw-a11y-high-contrast', prefs.highContrast);
    savePrefs();
  });
  btnContrast.setAttribute('aria-pressed', prefs.highContrast ? 'true' : 'false');
  toolbar.appendChild(btnContrast);

  // Desaturate toggle
  var btnDesat = createButton('🎨', 'Toggle desaturate / grayscale', function () {
    prefs.desaturate = !prefs.desaturate;
    toggleClass('aw-a11y-desaturate', prefs.desaturate);
    savePrefs();
  });
  btnDesat.setAttribute('aria-pressed', prefs.desaturate ? 'true' : 'false');
  toolbar.appendChild(btnDesat);

  // Dyslexia font toggle
  var btnDys = createButton('Dys', 'Toggle dyslexia-friendly font', function () {
    prefs.dyslexia = !prefs.dyslexia;
    toggleClass('aw-a11y-dyslexia', prefs.dyslexia);
    savePrefs();
  });
  btnDys.setAttribute('aria-pressed', prefs.dyslexia ? 'true' : 'false');
  toolbar.appendChild(btnDys);

  // Focus outline toggle
  var btnFocus = createButton('☑', 'Toggle focus outline', function () {
    prefs.focusOutline = !prefs.focusOutline;
    toggleClass('aw-a11y-focus-outline', prefs.focusOutline);
    savePrefs();
  });
  btnFocus.setAttribute('aria-pressed', prefs.focusOutline ? 'true' : 'false');
  toolbar.appendChild(btnFocus);

  // Font size increase / decrease / reset
  var btnIncrease = createButton('A+', 'Increase text size', function () {
    var current = prefs.fontScale || 1;
    var next = Math.min(2.5, (Math.round((current + 0.1) * 10) / 10));
    applyFontScale(next);
  });
  var btnDecrease = createButton('A-', 'Decrease text size', function () {
    var current = prefs.fontScale || 1;
    var next = Math.max(0.7, (Math.round((current - 0.1) * 10) / 10));
    applyFontScale(next);
  });
  var btnReset = createButton('Reset', 'Reset text and spacing', function () {
    prefs.fontScale = 1; applyFontScale(1); applyLineHeight('');
    prefs.lineHeight = undefined; prefs.fontScale = undefined; savePrefs();
    // applyAllPrefs will remove classes if undefined
    applyAllPrefs();
    // reload the page styles slightly
    setTimeout(function(){ location.reload(); }, 100);
  });
  toolbar.appendChild(btnIncrease);
  toolbar.appendChild(btnDecrease);
  toolbar.appendChild(btnReset);

  // Line height control quick toggles
  var btnLine1 = createButton('LH 1.2', 'Set line height 1.2', function () {
    applyLineHeight('1.2');
  });
  var btnLine2 = createButton('LH 1.6', 'Set line height 1.6', function () {
    applyLineHeight('1.6');
  });
  toolbar.appendChild(btnLine1);
  toolbar.appendChild(btnLine2);

  // Stop all (clear TTS and optionally reset)
  var btnClear = createButton('✖', 'Stop reading & clear temporary modes', function () {
    tts.stop();
    // clear transient prefs if you like - leave persistent toggles
    // For safety we only stop speech here
  });
  toolbar.appendChild(btnClear);

  // Apply stored prefs on load
  applyAllPrefs();

  // Make toolbar keyboard focusable
  toolbar.tabIndex = -1;

  // Inject toolbar at end of body
  document.body.appendChild(toolbar);

  // Accessibility: ensure toolbar buttons are keyboard accessible and show state in aria-pressed
  function refreshAria() {
    btnContrast.setAttribute('aria-pressed', prefs.highContrast ? 'true' : 'false');
    btnDesat.setAttribute('aria-pressed', prefs.desaturate ? 'true' : 'false');
    btnDys.setAttribute('aria-pressed', prefs.dyslexia ? 'true' : 'false');
    btnFocus.setAttribute('aria-pressed', prefs.focusOutline ? 'true' : 'false');
  }
  refreshAria();

  // ensure prefs saved on unload
  window.addEventListener('beforeunload', savePrefs);

  // expose a small API (optional)
  window.awA11y = {
    enableHighContrast: function(){ prefs.highContrast = true; toggleClass('aw-a11y-high-contrast', true); savePrefs(); refreshAria(); },
    disableHighContrast: function(){ prefs.highContrast = false; toggleClass('aw-a11y-high-contrast', false); savePrefs(); refreshAria(); },
    readSelection: function(){ btnRead.click(); },
    stopReading: function(){ tts.stop(); }
  };

})();
